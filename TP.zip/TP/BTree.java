import java.io.IOException;
import java.io.RandomAccessFile;

public class BTree{
    private int T;
    private int qtdNos=0;
    private boolean achou=false;
    
    // Node creation
    public class Node {
        int n;
        Elemento key[] = new Elemento[2 * T - 1];
        Node child[] = new Node[2 * T];
        boolean leaf = true;

        public int Find(int k) {
            for (int i = 0; i < this.n; i++) {
                if (this.key[i].id == k) {
                    return i;
                }
            }
            return -1;
        }
    }

    public BTree(int t) {
        T = t;
        root = new Node();
        root.n = 0;
        root.leaf = true;
    }

    private Node root;

    // Search key
    private Node Search(Node x, int key) {
        int i = 0;
        if (x == null){
            return x;
        }
        for (i = 0; i < x.n; i++) {
            if (key < x.key[i].id) { //se for menor que a chave atual, significa que não existe 
                break;
            }
            if (key == x.key[i].id) { //se for igual, achou o elemento
                return x;
            }
        }
        if (x.leaf) { //se tiver chegado no fim da folha sem contrar o elemento
            return null;
        } else { //se não for folha continua a busca, por meio de recursividade 
            return Search(x.child[i], key);
        }
    }

    // Splitting the node
    private void Split(Node x, int pos, Node y) {
        Node z = new Node();
        z.leaf = y.leaf;
        z.n = T - 1;
        for (int j = 0; j < T - 1; j++) {
            z.key[j] = y.key[j + T];
        }
        if (!y.leaf) {
            for (int j = 0; j < T; j++) {
            z.child[j] = y.child[j + T];
            }
        }
        y.n = T - 1;
        for (int j = x.n; j >= pos + 1; j--) {
            x.child[j + 1] = x.child[j];
        }
        x.child[pos + 1] = z;

        for (int j = x.n - 1; j >= pos; j--) {
            x.key[j + 1] = x.key[j];
        }
        x.key[pos] = y.key[T - 1];
        x.n = x.n + 1;
    }

    // Inserting a value
    public void Insert(final Elemento key) {
        Node r = root; //armazena a atual raiz
        if (r.n == 2 * T - 1) { //se a raiz estiver cheia 
            Node s = new Node(); //cria novo no, que será a nova raiz
            root = s; 
            s.leaf = false; //ja que é raiz, então não é folha
            s.n = 0; //qtd de elementos 
            s.child[0] = r; //inicializa os filhos com os elementos da antiga raiz
            Split(s, 0, r); 
            insertValue(s, key);
        } else {//raiz "vazia"
            insertValue(r, key);
        }
    }

    // Insert the node
    final private void insertValue(Node x, Elemento k) {
        if (x.leaf) { //se o no for folha
            int i = 0;
            for (i = x.n - 1; i >= 0 && k.id < x.key[i].id; i--) {//se a chave for menor que os elementos da folha
                x.key[i + 1] = x.key[i];
            }
            x.key[i + 1] = k;//insere na posição certa
            x.n = x.n + 1; //atualiza a qtd de elementos 
        } else { //se não for folha
            int i = 0;
            for (i = x.n - 1; i >= 0 && k.id < x.key[i].id; i--) {
                //acha a posicao do novo elemento que sera inserido
            }
            i++; //posição o ponteiro que levara para o proximo no filho
            Node tmp = x.child[i]; //no filho
            if (tmp.n == 2 * T - 1) { //se o no filho estiver cheio, realiza-se o split
            Split(x, i, tmp);
            if (k .id> x.key[i].id) {
                i++;
            }
            }
            insertValue(x.child[i], k); //recursividade ate achar uma folha
        }
    }

    public void Show() throws IOException {
        Show(root);
    }

   private void Show(Node x) { 
        //Le na ordem das paginas, de cima pra baixo - da esquerda para direita
        assert (x == null); 
        for (int i = 0; i < x.n; i++) { //percorre todos os elementos da pagina
            System.out.print(x.key[i].id + " ");
        }
        System.out.print("\n");
        if (!x.leaf) { //se a pagina não for folha, continua o processo de percorrer a árvore 
            for (int i = 0; i < x.n + 1; i++) {
                Show(x.child[i]); //rescurividade ate chegar nas folhas
            }
        }
    }

    public void writeArqIndice() throws IOException {
        writeArqIndice(root);
    }
    public void writeArqIndice(Node x) throws IOException {  //tam fixo por pagina = 8*7 + 8*4 + 4 = 92 bytes
        RandomAccessFile arq = new RandomAccessFile("arquivoB", "rw");
        int contPonteiro = 0;

        if(contPonteiro==0){
            arq.writeInt(4);
            contPonteiro = 4;
        }
        int cont=0;
        if(x == root){
            arq.seek(contPonteiro);
            arq.writeInt(x.n); //qtd de elementos na folha
            contPonteiro += 92;
            for (int i = 0; i < x.n; i++) {
                arq.writeInt(contPonteiro); 
                arq.writeInt(x.key[i].id);
                arq.writeInt(x.key[i].address); 
                contPonteiro = writeRec(x.child[cont++], contPonteiro) + 92;
                qtdNos=0;
            }
            contPonteiro = writeRec(x.child[cont++], contPonteiro);
            contPonteiro = contPonteiro - (92*(qtdNos-1));
            arq.writeInt(contPonteiro); //System.out.println(contPonteiro);
        }
        //readArqB();
        /*imprime a pagina e todos os filhos ate chegar na folha, depois sobe para o proximo elemento da raiz
        assert (x == null);
        for (int i = 0; i < x.n; i++) {
            System.out.print(x.key[i].id + " ");
        }
        if (!x.leaf) {
            for (int i = 0; i < x.n + 1; i++) {
                Show(x.child[i]);
            }
        } */
    }
    public int writeRec(Node x, int contPonteiro) throws IOException{
        RandomAccessFile arq = new RandomAccessFile("arquivoB", "rw");
        int pontLeaf = -1;
        int cont=0;
        if(x!=null){
            qtdNos++;
            if(!x.leaf){ //NÃO FOLHA
                arq.seek(contPonteiro);
                arq.writeInt(x.n); //qtd de elementos na folha
                contPonteiro += 92;
                for (int i = 0; i < x.n; i++) {
                    arq.writeInt(contPonteiro);
                    arq.writeInt(x.key[i].id);
                    arq.writeInt(x.key[i].address);
                    contPonteiro = writeRec(x.child[cont++], contPonteiro)+92;
                }    
                arq.writeInt(contPonteiro);            
                contPonteiro = writeRec(x.child[cont++], contPonteiro);
                               
            }else{ //FOLHA
                arq.seek(contPonteiro); //-1
                arq.writeInt(x.n); //qtd de elementos na folha
                for (int i = 0; i < x.n; i++) {
                    arq.writeInt(pontLeaf);
                    arq.writeInt(x.key[i].id);
                    arq.writeInt(x.key[i].address);
                }
                arq.writeInt(pontLeaf); //-1
            }
        }
        return contPonteiro;
    }
    
    public void readArqB() throws IOException{
        RandomAccessFile arq = new RandomAccessFile("arquivoB", "rw");
        int pos=4;
        do{
            arq.seek(pos);
            int qtd = arq.readInt();
            System.out.println("Qtd: "+qtd);
            for(int i=0; i<qtd; i++){
                System.out.println("pont: "+arq.readInt());
                System.out.println("elemento: "+arq.readInt());
                System.out.println("address: "+arq.readInt());
            }
            System.out.println("pont: "+arq.readInt());
            pos+=92;
        }while(pos<=arq.length());   
    }

    public int SearchArq(int id) throws IOException{
        achou=false;
        int address = SearchArq(0, id);
        return address;
    }

    private int SearchArq(int pos, int id) throws IOException{
        RandomAccessFile arq = new RandomAccessFile("arquivoB", "rw");
        int pontAnt=0, pontPos;
        int elemento;
        int endereco=-1;

        if(pos==0){
            arq.seek(pos);
            pos = arq.readInt();
        }
        
        arq.seek(pos);
        int qtd = arq.readInt();
        for(int i=0; i<qtd; i++){
            pontAnt = arq.readInt();
            elemento = arq.readInt(); 
            endereco = arq.readInt(); 
            if(elemento==id){
                //System.out.println("ENDEREÇO ==== "+endereco);
                achou=true;
                return endereco;
            }else if(id<elemento && pontAnt!=-1){
                endereco = SearchArq(pontAnt, id);
            }else{
                endereco=0;
            }
            if(achou){
                break;
            }
        }
        
        if(endereco==0 && pontAnt!=-1){
            pontPos = arq.readInt();  
            endereco = SearchArq(pontPos, id); 
        }
        if(achou==false){
            endereco=-1;
        }
        //System.out.println("ENDEREÇO 2 ==== "+endereco);
        return endereco;
    }

    // Check if present
    public boolean Contain(int k) {
        if (this.Search(root, k) != null) {
            return true;
        } else {
            return false;
        }
    }

    public void updateAddress(int id, int address) throws IOException{
        //tam fixo por pagina = 8*7 + 8*4 + 4 = 92 bytes
        RandomAccessFile arq = new RandomAccessFile("arquivoB", "rw");
        int pos=4, pont;
        do{
            arq.seek(pos);
            int qtd = arq.readInt();
            for(int i=0; i<qtd; i++){
                pont = arq.readInt();
                int elemento = arq.readInt();
                if(elemento == id){
                    arq.writeInt(address);
                    break;
                }else{
                    pont = arq.readInt();
                }
            }
            pont = arq.readInt();
            pos+=92;
        }while(pos<=arq.length());   
    }
}
class Elemento{
    int id;
    int address;

    public Elemento(int k, int a){
        id = k;
        address = a;
    }
}